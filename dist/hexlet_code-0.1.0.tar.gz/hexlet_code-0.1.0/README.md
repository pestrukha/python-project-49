### Hexlet tests and linter status:
[![Actions Status](https://github.com/pestrukha/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/pestrukha/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/97446d47a3b34883f6fd/maintainability)](https://codeclimate.com/github/pestrukha/python-project-49/maintainability)
[![asciicast](https://asciinema.org/a/LMnIPEKGINaBqahEbnOLBZjPD.svg)](https://asciinema.org/a/LMnIPEKGINaBqahEbnOLBZjPD)