from brain_games.games.logic import play_game

def play_calc_game():
    play_game('calc', 'What is the result of the expression?')