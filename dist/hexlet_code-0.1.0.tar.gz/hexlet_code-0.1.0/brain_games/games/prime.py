from brain_games.games.logic import play_game

def play_prime_game():
    play_game('prime', 'Answer "yes" if given number is prime. Otherwise answer "no".')