from brain_games.games.logic import play_game

def play_gcd_game():
    play_game('gcd', 'Find the greatest common divisor of given numbers.')