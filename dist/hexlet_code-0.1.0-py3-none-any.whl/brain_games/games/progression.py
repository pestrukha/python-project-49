from brain_games.games.logic import play_game

def play_progression_game():
    play_game('progression', 'What number is missing in the progression?')