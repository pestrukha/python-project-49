from brain_games.games.logic import play_game

def play_even_game():
    play_game('even', 'Answer "yes" if the number is even, otherwise answer "no".')